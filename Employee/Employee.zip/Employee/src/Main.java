public class Main {
    public static void main(String[] args) {
        Employee e1 = new Employee("Alex",2000,45,1985);
        Employee e2 = new Employee("Michael",2000,50,2000);
        e1.printInfo();
        e2.printInfo();




    }
}
